﻿<div class="row1">
    <div class="col-md-8">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">
                    <span class="glyphicon glyphicon-bookmark"></span>
                    Navigation
                </h3>
            </div>
            <div class="wrapper">
                <a href="index.php?uc=gererFrais&action=saisirFrais" class="button">Renseigner la fiche de frais</a>
            </div>
            <div class="wrapper1">
                <a href="index.php?uc=etatFrais&action=selectionnerMois" class="button1">Afficher mes fiches de frais</a>
            </div>
        </div>
    </div>
</div>