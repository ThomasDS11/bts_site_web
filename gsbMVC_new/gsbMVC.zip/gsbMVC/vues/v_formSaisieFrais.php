<html>
<head>
	<title>Gestion des frais de visite</title>
	<style type="text/css">
		<!-- body {background-color: white; color:5599EE; }
			.titre { width : 180 ;  clear:left; float:left; } 
			.zone { float : left; color:7091BB } -->
	</style>
	<script language="javascript">
        function ajoutLigne( pNumero){//ajoute une ligne de produits/qt� � la div "lignes"     
			//masque le bouton en cours
			document.getElementById("but"+pNumero).setAttribute("hidden","true");	
			pNumero++;										//incr�mente le num�ro de ligne
            var laDiv=document.getElementById("lignes");	//r�cup�re l'objet DOM qui contient les donn�es
			var titre = document.createElement("label") ;	//cr�e un label
			laDiv.appendChild(titre) ;						//l'ajoute � la DIV
			titre.setAttribute("class","titre") ;			//d�finit les propri�t�s
			titre.innerHTML= "   "+ pNumero + " : ";
			//zone our la date du frais
			var ladate = document.createElement("input");
			laDiv.appendChild(ladate);
			ladate.setAttribute("name","FRA_AUT_DAT"+pNumero);
			ladate.setAttribute("size","12"); 
			ladate.setAttribute("class","zone");
			ladate.setAttribute("type","text");	
			//zone de saisie pour un nouveau libell�			
			var libelle = document.createElement("input");
			laDiv.appendChild(libelle);
			libelle.setAttribute("name","FRA_AUT_LIB"+pNumero);
			libelle.setAttribute("size","30"); 
			libelle.setAttribute("class","zone");
			libelle.setAttribute("type","text");
			//zone de saisie pour un nouveau montant		
			var mont = document.createElement("input");
			laDiv.appendChild(mont);
			mont.setAttribute("name","FRA_AUT_MONT"+pNumero);
			mont.setAttribute("size","3"); 
			mont.setAttribute("class","zone");
			mont.setAttribute("type","text");			
			var bouton = document.createElement("input");
			laDiv.appendChild(bouton);
			//ajoute une gestion �venementielle en faisant �voluer le num�ro de la ligne
			bouton.setAttribute("onClick","ajoutLigne("+ pNumero +");");
			bouton.setAttribute("type","button");
			bouton.setAttribute("value","+");
			bouton.setAttribute("class","zone");	
			bouton.setAttribute("id","but"+ pNumero);				
        }
    </script>
	<script>
	</script
</head>
<body>
<div name="gauche" style="clear:left:;float:left;width:18%; background-color:white; height:100%;">
<div name="coin" style="height:10%;text-align:center;"><img src="images/logo.jpg" width="100" height="60"/></div>
<div name="menu" >
	<h2>Outils</h2>
	<ul><li>Frais</li>
		<ul>
			<li><a href="v_formSaisieFrais.php" >Nouveau</a></li>
			<li><a href="v_formConsultFrais.php">Consulter</a></li>
		</ul>
	</ul>
</div>
</div>
<div name="droite" style="float:left;width:80%;">
	<div name="haut" style="margin: 2 2 2 2 ;height:10%;float:left;"><h1>Gestion des Frais</h1></div>	
	<div name="bas" style="margin : 10 2 2 2;clear:left;background-color:77AADD;color:white;height:88%;">
	<form name="formSaisieFrais" method="post" action="enregSaisieFrais.php">
		<h1> Saisie </h1>
		<label class="titre">PERIODE D'ENGAGEMENT :</label>
			<label style="float:left;">Mois (2 chiffres) : </label><input type="text" size="4" name="FRA_MOIS" class="zone" />
			<label style="float:left;">&nbsp;Annee (4 chiffres) : </label><input type="text" size="4" name="FRA_AN" class="zone" />
		<p class="titre" /><div style="clear:left;"><h2>Frais au forfait</h2></div>
		<label class="titre">Repas midi :</label><input type="text" size="2" name="FRA_REPAS" class="zone" />
		<label class="titre">Nuitees :</label><input type="text" size="2" name="FRA_NUIT" class="zone" />
		<label class="titre">Etape :</label><input type="text" size="5" name="FRA_ETAP" class="zone" />
		<label class="titre">Km :</label><input type="text" size="5" name="FRA_KM" class="zone" />
		<p class="titre" /><div style="clear:left;"><h2>Hors Forfait</h2></div>
		<div style="clear:left;">			
			<div style="margin-left:180;float:left;width:90;text-align:center;">Date</div>
			<div style="float:left;width:220;text-align:center;">Libell�</div>
			<div style="float:left;width:30;text-align:center;">Montant</div>
		</div>
		<div style="clear:left;" id="lignes">
			<label class="titre" > 1 : </label>
			<input type="text" size="12" name="FRA_AUT_DAT1" class="zone"/>
			<input type="text" size="30" name="FRA_AUT_LIB1" class="zone"/>
			<input class="zone" size="3" name="FRA_AUT_MONT1" type="text" />				
			<input type="button" id="but1" value="+" onclick="ajoutLigne(1);" class="zone" />			
		</div>	
		<p class="titre" /><label class="titre">&nbsp;</label><input class="zone"type="reset" /><input class="zone"type="submit" />
	</form>
	</div>
</div>
</body>
</html>