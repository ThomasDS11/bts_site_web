﻿<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="UTF-8">
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>Intranet du Laboratoire Galaxy-Swiss Bourdin</title>
    <link href="../styles/style2.css" rel="stylesheet" type="text/css" />
    <link href="./styles/bootstrap/bootstrap.css" rel="stylesheet">
    <link rel="shortcut icon" type="image/x-icon" href="../images/logo.jpg" />

  </head>
      <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
      <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <body>
    
